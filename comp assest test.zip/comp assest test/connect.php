<?php
$servername = "localhost";
$username = "tyson";
$password = "";
$dbname = "Compassets";

$con = new mysqli($servername, $username, $password,$dbname);

?>